package com.user_details;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserDetails1Application {

	public static void main(String[] args) {
		SpringApplication.run(UserDetails1Application.class, args);
	}

}
